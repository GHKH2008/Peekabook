// Using Open Library API - free, no API key, no rate limits
// https://openlibrary.org/developers/api

export type OpenLibraryBook = {
  key: string
  title: string
  author_name?: string[]
  first_publish_year?: number
  publisher?: string[]
  language?: string[]
  subject?: string[]
  isbn?: string[]
  cover_i?: number
  number_of_pages_median?: number
}

export type OpenLibraryResponse = {
  numFound: number
  docs: OpenLibraryBook[]
}

export async function searchBooks(
  query: string,
  language?: string
): Promise<OpenLibraryBook[]> {
  if (!query.trim()) return []

  const params = new URLSearchParams({
    q: query,
    limit: '20',
    fields: 'key,title,author_name,first_publish_year,publisher,language,subject,isbn,cover_i,number_of_pages_median',
  })

  // Filter by language if specified
  if (language && language !== 'any') {
    params.set('language', language)
  }

  try {
    const response = await fetch(
      `https://openlibrary.org/search.json?${params.toString()}`
    )

    if (!response.ok) {
      throw new Error(`Open Library API error: ${response.status}`)
    }

    const data: OpenLibraryResponse = await response.json()
    return data.docs || []
  } catch (error) {
    console.error('Open Library search error:', error)
    throw new Error('Failed to search books. Please try again.')
  }
}

export function getCoverUrl(coverId: number | undefined, size: 'S' | 'M' | 'L' = 'M'): string | null {
  if (!coverId) return null
  return `https://covers.openlibrary.org/b/id/${coverId}-${size}.jpg`
}

export function parseOpenLibraryBook(book: OpenLibraryBook) {
  const isbns = book.isbn || []
  const isbn10 = isbns.find(i => i.length === 10) || null
  const isbn13 = isbns.find(i => i.length === 13) || null
  
  return {
    google_books_id: book.key, // Using Open Library key as unique ID
    title: book.title,
    authors: book.author_name || null,
    summary: null, // Open Library search doesn't return descriptions
    genres: book.subject?.slice(0, 5) || null, // Limit to 5 subjects
    isbn: isbn10,
    isbn_13: isbn13,
    language: book.language?.[0] || null,
    cover_url: getCoverUrl(book.cover_i, 'M'),
    publisher: book.publisher?.[0] || null,
    published_date: book.first_publish_year?.toString() || null,
    page_count: book.number_of_pages_median || null,
    is_adult: false, // Open Library doesn't provide maturity rating
  }
}

// Keep backward compatibility with existing function names
export { searchBooks as searchGoogleBooks }
export { parseOpenLibraryBook as parseGoogleBook }
export type { OpenLibraryBook as GoogleBook }
